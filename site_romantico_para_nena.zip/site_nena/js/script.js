const surpriseBtn = document.getElementById('surpriseBtn');
const finale = document.getElementById('surpresa');
const backBtn = document.getElementById('backBtn');
const song = document.getElementById('ourSong');
const musicToggle = document.getElementById('musicToggle');

surpriseBtn.addEventListener('click', () => {
  finale.hidden = false;
  finale.scrollIntoView({ behavior: 'smooth', block: 'start' });
});

backBtn.addEventListener('click', () => {
  document.getElementById('inicio').scrollIntoView({ behavior: 'smooth' });
});

musicToggle.addEventListener('click', async () => {
  if (song.paused) {
    try {
      await song.play();
      musicToggle.textContent = 'Ⅱ Pausar música';
      musicToggle.setAttribute('aria-pressed', 'true');
    } catch {
      musicToggle.textContent = '♫ Use o player abaixo';
      document.getElementById('musica').scrollIntoView({ behavior: 'smooth' });
    }
  } else {
    song.pause();
    musicToggle.textContent = '♫ Música';
    musicToggle.setAttribute('aria-pressed', 'false');
  }
});

song.addEventListener('play', () => {
  musicToggle.textContent = 'Ⅱ Pausar música';
  musicToggle.setAttribute('aria-pressed', 'true');
});
song.addEventListener('pause', () => {
  musicToggle.textContent = '♫ Música';
  musicToggle.setAttribute('aria-pressed', 'false');
});
