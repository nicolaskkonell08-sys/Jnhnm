SITE ROMÂNTICO PARA NENA — COMO PERSONALIZAR E PUBLICAR

1) TESTAR NO CELULAR OU COMPUTADOR
- Extraia o arquivo ZIP.
- Abra index.html no navegador.
- Para testar a música, coloque um arquivo MP3 na pasta musica com o nome nossa-musica.mp3.
- O site usa uma fonte do Google Fonts; se estiver sem internet, o navegador usa fontes alternativas.

2) PERSONALIZAR
- Abra index.html num editor de texto.
- Troque as mensagens que quiser mantendo as tags HTML.
- A música fica em musica/nossa-musica.mp3.
- Evite publicar fotos privadas ou informações pessoais sem consentimento.

3) PUBLICAR DE GRAÇA COM GITHUB PAGES
- Crie uma conta em https://github.com/
- Clique em New repository e dê um nome como nena-surpresa. Para facilitar, marque Public.
- Dentro do repositório, use Add file > Upload files.
- Envie os arquivos e pastas que estão dentro do ZIP extraído (index.html, css, js, musica e README.txt).
- Clique em Commit changes.
- Abra Settings > Pages.
- Em Build and deployment, escolha Deploy from a branch.
- Escolha a branch main e a pasta /(root), depois Save.
- Aguarde alguns minutos. O GitHub mostrará o endereço público do site na área Pages.

4) IMPORTANTE
- Não compartilhe senha, dados pessoais ou fotos privadas.
- O site não envia respostas nem coleta dados; o botão final apenas revela a surpresa.
- A música não toca automaticamente; a pessoa pode escolher tocar ou pausar.
- Como é uma página estática, funciona sem servidor próprio e pode ser hospedada gratuitamente.
